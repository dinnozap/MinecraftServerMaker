﻿Public Class Form2

    Private Sub FlatNumeric1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub FlatButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton1.Click
        My.Computer.Network.DownloadFile("https://raw.githubusercontent.com/dinnozap/MinecraftServerMaker/master/base.py",
    FlatTextBox1.Text + "\base.py")
        My.Computer.Network.DownloadFile("https://raw.githubusercontent.com/dinnozap/MinecraftServerMaker/master/main.py",
FlatTextBox1.Text + "\main.py")
        My.Computer.Network.DownloadFile("https://raw.githubusercontent.com/dinnozap/MinecraftServerMaker/master/commun.py",
FlatTextBox1.Text + "\commun.py")
        Me.Visible = False
        Form3.Visible = True

    End Sub

    Private Sub FlatButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton2.Click
        FolderBrowserDialog1.ShowDialog()
        FlatTextBox1.Text = FolderBrowserDialog1.SelectedPath + "\MinecraftServerMaker"

    End Sub
End Class