﻿Public Class Form3

    Private Sub FlatButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton1.Click
        If FlatCheckBox1.Checked() = True Then
            System.Diagnostics.Process.Start(Form2.FlatTextBox1.Text + "\main.py")
            End

        End If

    End Sub
End Class